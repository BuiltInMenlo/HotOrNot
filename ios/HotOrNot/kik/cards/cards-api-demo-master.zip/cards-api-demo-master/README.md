###[Full Documentation of the Cards Platform can be Found Here](http://cards.kik.com/docs/)

## Messaging

    // Send a message

    cards.kik.send({
        title     : 'Message title'                ,
        text      : 'Message body'                 ,
        pic       : 'http://picture.com/image.jpg' , // optional
        big       : true                           , // optional
        noForward : true                           , // optional
        data      : { some : 'json' }                // optional
    });

    // Get data from message

    if ( cards.kik.message ) {
      cards.kik.message === data; // true
    }

## User Graph

    // A user is of the form

    var User = {
        username  = 'string',
        fullName  = 'string',
        firstName = 'string',
        lastName  = 'string',
        pic       = 'string',
        thumbnail = 'string'
    }

    // Get user profile

    cards.kik.getUser(function ( user ) {
      if ( !user ) {
        // user data request was denied
        return;
      }
      doStuff(user);
    });

    // Users can also bring up a list of their contacts and access their information
    // Useful if you want to build a friends based leaderboard

    cards.kik.pickUsers(function ( array_of_users ) {

      if ( !array_of_users ) {
        // No one was selected
        return;
      }

      array_of_users.forEach(function ( user ) {
        doStuff(user.username);
      });

    });

## Push

    // Get a push token of a user

    cards.push.getToken(function ( token ) {
      if ( token ) {
        // Unique string allowing you to send pushes to this user
      }
    });


















