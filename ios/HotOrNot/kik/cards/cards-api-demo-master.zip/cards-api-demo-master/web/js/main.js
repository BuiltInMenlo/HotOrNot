App.load('home');

$('#send_message_article').on('click', function () {
	cards.kik.send({
    title     : 'API Demo'                                      ,
    text      : 'Lorem ipsum dolor sit amet, '+
                 'consectetur adipiscing elit. ' +
    						 'Sed mi nulla, tincidunt vel ' +
    						 'condimentum eu, aliquet non neque.'            ,
    pic       : 'http://code.kik.com/app/demos/apps/reddit.png' ,
    data      : { highScore : 500, username : 'some_dude' }
	});
});


$('#send_message_full').on('click', function () {
	cards.kik.send({
    title     : 'API Demo'                                      ,
    pic       : 'http://code.kik.com/app/demos/apps/reddit.png' ,
    big				: true																						,
    data      : { highScore : 100000, username : 'another_guy' }
	});
});

$('#get_user').on('click', function () {
	cards.kik.getUser(function ( user ) {
		console.log(user);
		App.load('from-message', user);
	});
});

$('#get_users').on('click', function () {
	cards.kik.pickUsers(function ( array_of_users ) {
		console.log(array_of_users)
		App.load('from-message', array_of_users);

	});
});

$('#push_token').on('click', function () {
cards.push.getToken(function ( token ) {
  if ( token ) {
    // Unique string allowing you to send pushes to this user
    console.log(token);
		App.load('from-message', {'token' : token});
  }
});
});