App.populator('home', function ( page ) {
  if (cards.kik.message) {
    App.load('from-message', cards.kik.message);
  }
});