App.populator('from-message', function (page, data) {
  $(page).find('#dataz').css('word-wrap', 'break-word');
  $(page).find('#dataz').text(JSON.stringify(data));
})