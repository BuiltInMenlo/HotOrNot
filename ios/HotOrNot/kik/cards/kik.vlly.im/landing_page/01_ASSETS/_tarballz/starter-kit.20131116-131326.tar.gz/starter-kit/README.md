# Welcome to your starter kit

### Setup

1. Install Node.js (v0.8+) from [http://nodejs.org/](http://nodejs.org/)
2. Run these commands:

```sh
git clone git://github.com/kikinteractive/starter-kit.git
cd starter-kit
npm install
```

### Run debug server

1. Run this command: `npm start`
2. Go to [localhost:5000](http://localhost:5000/) in your browser to see your app
