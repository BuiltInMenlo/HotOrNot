//
//  AppDelegate.h
//  BlowfishTest
//
//  Created by Prabu Arumugam on 23/03/13.
//  Copyright (c) 2013 CODEDING. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;

@end
