/*
 * Copyright 2010 Facebook
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "Facebook.h"
#import "FBFrictionlessRequestSettings.h"
#import "FBLoginDialog.h"
#import "FBRequest.h"
#import "FBError.h"
#import "FBSessionManualTokenCachingStrategy.h"
#import "FBSBJSON.h"
#import "FBSession+Internal.h"
#import "FBUtility.h"

static NSString* kDialogBaseURL = @"https://m." FB_BASE_URL "/dialog/";
static NSString* kGraphBaseURL = @"https://graph." FB_BASE_URL "/";
static NSString* kRestserverBaseURL = @"https://api." FB_BASE_URL "/method/";

static NSString* kFBAppAuthURLScheme = @"fbauth";
static NSString* kFBAppAuthURLPath = @"authorize";
static NSString* kRedirectURL = @"fbconnect://success";
static NSString* kSDK = @"ios";

static NSString* kLogin = @"oauth";
static NSString* kApprequests = @"apprequests";
static NSString* kSDKVersion = @"2";

// If the last time we extended the access token was more than 24 hours ago
// we try to refresh the access token again.
static const int kTokenExtendThreshold = 24;

static NSString *requestFinishedKeyPath = @"state";
static void *finishedContext = @"finishedContext";
static void *tokenContext = @"tokenContext";

// the following const strings name properties for which KVO is manually handled
static NSString *const FBaccessTokenPropertyName = @"accessToken";
static NSString *const FBexpirationDatePropertyName = @"expirationDate";

///////////////////////////////////////////////////////////////////////////////////////////////////

@interface Facebook ()

@end

///////////////////////////////////////////////////////////////////////////////////////////////////

@implementation Facebook

@synthesize session = _session,
            fbDialog = _fbDialog;

///////////////////////////////////////////////////////////////////////////////////////////////////
// private


- (id)initWithFBSession:(FBSession *)session
{
    self = [super init];
    if( self ) {
        if( session ) {
            _session = session;
        }
        else {
            _session = FBSession.activeSession;
        }
        [_session retain];
        _requests = [[NSMutableSet alloc] init];
        _frictionlessRequestSettings = [[FBFrictionlessRequestSettings alloc] init];
    }
    return self;
}

/**
 * Override NSObject : free the space
 */
- (void)dealloc {

    [_session release];
    for (FBRequest* _request in _requests) {
        [_request removeObserver:self forKeyPath:requestFinishedKeyPath];
    }
    [_requests release];
    _fbDialog.delegate = nil;
    [_fbDialog release];
    [_frictionlessRequestSettings release];
    [super dealloc];
}

- (NSString *)accessToken {
    return self.session.accessToken;
}

- (NSDate *)expirationDate {
    return self.session.expirationDate;
}

- (BOOL)isSessionValid {
    return self.session.isOpen;
}

/**
 * This function processes the URL the Facebook application or Safari used to
 * open your application during a Facebook Login flow.
 *
 * You MUST call this function in your UIApplicationDelegate's handleOpenURL
 * method (see
 * http://developer.apple.com/library/ios/#documentation/uikit/reference/UIApplicationDelegate_Protocol/Reference/Reference.html
 * for more info).
 *
 * This will ensure that the authorization process will proceed smoothly once the
 * Facebook application or Safari redirects back to your application.
 *
 * @param URL the URL that was passed to the application delegate's handleOpenURL method.
 *
 * @return YES if the URL starts with 'fb[app_id]://authorize and hence was handled
 *   by SDK, NO otherwise.
 */
- (BOOL)handleOpenURL:(NSURL *)url {
    return [self.session handleOpenURL:url];
}

/**
 * Make a request to Facebook's REST API with the given
 * parameters. One of the parameter keys must be "method" and its value
 * should be a valid REST server API method.
 *
 * See http://developers.facebook.com/docs/reference/rest/
 *
 * @param parameters
 *            Key-value pairs of parameters to the request. Refer to the
 *            documentation: one of the parameters must be "method".
 * @param delegate
 *            Callback interface for notifying the calling application when
 *            the request has received response
 * @return FBRequest*
 *            Returns a pointer to the FBRequest object.
 */
- (FBRequest*)requestWithParams:(NSMutableDictionary *)params
                    andDelegate:(id <FBRequestDelegate>)delegate {
    if ([params objectForKey:@"method"] == nil) {
        NSLog(@"API Method must be specified");
        return nil;
    }
    
    NSString * methodName = [params objectForKey:@"method"];
    [params removeObjectForKey:@"method"];
    
    return [self requestWithMethodName:methodName
                             andParams:params
                         andHttpMethod:@"GET"
                           andDelegate:delegate];
}

/**
 * Make a request to Facebook's REST API with the given method name and
 * parameters.
 *
 * See http://developers.facebook.com/docs/reference/rest/
 *
 *
 * @param methodName
 *             a valid REST server API method.
 * @param parameters
 *            Key-value pairs of parameters to the request. Refer to the
 *            documentation: one of the parameters must be "method". To upload
 *            a file, you should specify the httpMethod to be "POST" and the
 *            “params” you passed in should contain a value of the type
 *            (UIImage *) or (NSData *) which contains the content that you
 *            want to upload
 * @param delegate
 *            Callback interface for notifying the calling application when
 *            the request has received response
 * @return FBRequest*
 *            Returns a pointer to the FBRequest object.
 */
- (FBRequest*)requestWithMethodName:(NSString *)methodName
                          andParams:(NSMutableDictionary *)params
                      andHttpMethod:(NSString *)httpMethod
                        andDelegate:(id <FBRequestDelegate>)delegate {
    [self.session extendAccessTokenIfNeeded];

    FBRequest *request = [[FBRequest alloc] initWithSession:self.session
                                                 restMethod:methodName
                                                 parameters:params
                                                 HTTPMethod:httpMethod];
    [request setDelegate:delegate];
    [request startWithCompletionHandler:nil];

    return request;
}

/**
 * Make a request to the Facebook Graph API without any parameters.
 *
 * See http://developers.facebook.com/docs/api
 *
 * @param graphPath
 *            Path to resource in the Facebook graph, e.g., to fetch data
 *            about the currently logged authenticated user, provide "me",
 *            which will fetch http://graph.facebook.com/me
 * @param delegate
 *            Callback interface for notifying the calling application when
 *            the request has received response
 * @return FBRequest*
 *            Returns a pointer to the FBRequest object.
 */
- (FBRequest*)requestWithGraphPath:(NSString *)graphPath
                       andDelegate:(id <FBRequestDelegate>)delegate {
    
    return [self requestWithGraphPath:graphPath
                            andParams:[NSMutableDictionary dictionary]
                        andHttpMethod:@"GET"
                          andDelegate:delegate];
}

/**
 * Make a request to the Facebook Graph API with the given string
 * parameters using an HTTP GET (default method).
 *
 * See http://developers.facebook.com/docs/api
 *
 *
 * @param graphPath
 *            Path to resource in the Facebook graph, e.g., to fetch data
 *            about the currently logged authenticated user, provide "me",
 *            which will fetch http://graph.facebook.com/me
 * @param parameters
 *            key-value string parameters, e.g. the path "search" with
 *            parameters "q" : "facebook" would produce a query for the
 *            following graph resource:
 *            https://graph.facebook.com/search?q=facebook
 * @param delegate
 *            Callback interface for notifying the calling application when
 *            the request has received response
 * @return FBRequest*
 *            Returns a pointer to the FBRequest object.
 */
- (FBRequest*)requestWithGraphPath:(NSString *)graphPath
                         andParams:(NSMutableDictionary *)params
                       andDelegate:(id <FBRequestDelegate>)delegate {
    
    return [self requestWithGraphPath:graphPath
                            andParams:params
                        andHttpMethod:@"GET"
                          andDelegate:delegate];
}

/**
 * Make a request to the Facebook Graph API with the given
 * HTTP method and string parameters. Note that binary data parameters
 * (e.g. pictures) are not yet supported by this helper function.
 *
 * See http://developers.facebook.com/docs/api
 *
 *
 * @param graphPath
 *            Path to resource in the Facebook graph, e.g., to fetch data
 *            about the currently logged authenticated user, provide "me",
 *            which will fetch http://graph.facebook.com/me
 * @param parameters
 *            key-value string parameters, e.g. the path "search" with
 *            parameters {"q" : "facebook"} would produce a query for the
 *            following graph resource:
 *            https://graph.facebook.com/search?q=facebook
 *            To upload a file, you should specify the httpMethod to be
 *            "POST" and the “params” you passed in should contain a value
 *            of the type (UIImage *) or (NSData *) which contains the
 *            content that you want to upload
 * @param httpMethod
 *            http verb, e.g. "GET", "POST", "DELETE"
 * @param delegate
 *            Callback interface for notifying the calling application when
 *            the request has received response
 * @return FBRequest*
 *            Returns a pointer to the FBRequest object.
 */
- (FBRequest*)requestWithGraphPath:(NSString *)graphPath
                         andParams:(NSMutableDictionary *)params
                     andHttpMethod:(NSString *)httpMethod
                       andDelegate:(id <FBRequestDelegate>)delegate {
    [self.session extendAccessTokenIfNeeded];

    FBRequest *request = [[FBRequest alloc] initWithSession:self.session
                                                  graphPath:graphPath
                                                 parameters:params
                                                 HTTPMethod:httpMethod];
    [request setDelegate:delegate];
    [request startWithCompletionHandler:nil];

    return request;
}

/**
 * Generate a UI dialog for the request action.
 *
 * @param action
 *            String representation of the desired method: e.g. "login",
 *            "feed", ...
 * @param delegate
 *            Callback interface to notify the calling application when the
 *            dialog has completed.
 */
- (void)dialog:(NSString *)action
   andDelegate:(id<FBDialogDelegate>)delegate {
    NSMutableDictionary * params = [NSMutableDictionary dictionary];
    [self dialog:action andParams:params andDelegate:delegate];
}

/**
 * Generate a UI dialog for the request action with the provided parameters.
 *
 * @param action
 *            String representation of the desired method: e.g. "login",
 *            "feed", ...
 * @param parameters
 *            key-value string parameters
 * @param delegate
 *            Callback interface to notify the calling application when the
 *            dialog has completed.
 */
- (void)dialog:(NSString *)action
     andParams:(NSMutableDictionary *)params
   andDelegate:(id <FBDialogDelegate>)delegate {
    
    [self dialog:action andParams:params andDelegate:delegate hidden:YES];
}

- (void)dialog:(NSString *)action
     andParams:(NSMutableDictionary *)params
   andDelegate:(id <FBDialogDelegate>)delegate
        hidden:(BOOL)hidden {
    
    [_fbDialog release];
    
    NSString *dialogURL = [kDialogBaseURL stringByAppendingString:action];
    [params setObject:kSDK forKey:@"sdk"];
    [params setObject:kSDKVersion forKey:@"sdk_version"];
    [params setObject:kRedirectURL forKey:@"redirect_uri"];
    
    if ([action isEqualToString:@"send"]) {
        dialogURL = [dialogURL stringByReplacingOccurrencesOfString:@"m.facebook" withString:@"www.facebook"];
        [params setObject:@"popup" forKey:@"display"];
    }
    else {
        [params setObject:@"touch" forKey:@"display"];
    }
    
    [params setObject:self.session.appID forKey:@"app_id"];
    if ([self isSessionValid]) {
        [params setValue:[self.accessToken stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding] forKey:@"access_token"];
        [self.session extendAccessTokenIfNeeded];
    }
    
    // by default we show dialogs, frictionless cases may have a hidden view
    BOOL invisible = NO;
    
    // frictionless handling for application requests
    if ([action isEqualToString:kApprequests]) {
        // if frictionless requests are enabled
        if (self.isFrictionlessRequestsEnabled) {
            //  1. show the "Don't show this again for these friends" checkbox
            //  2. if the developer is sending a targeted request, then skip the loading screen
            [params setValue:@"1" forKey:@"frictionless"];
            //  3. request the frictionless recipient list encoded in the success url
            [params setValue:@"1" forKey:@"get_frictionless_recipients"];
        }
        
        // set invisible if all recipients are enabled for frictionless requests
        id fbid = [params objectForKey:@"to"];
        if (fbid != nil) {
            // if value parses as a json array expression get the list that way
            FBSBJsonParser *parser = [[[FBSBJsonParser alloc] init] autorelease];
            id fbids = [parser objectWithString:fbid];
            if (![fbids isKindOfClass:[NSArray class]]) {
                // otherwise seperate by commas (handles the singleton case too)
                fbids = [fbid componentsSeparatedByString:@","];
            }                
            invisible = [self isFrictionlessEnabledForRecipients:fbids];             
        }
    }
    
    _fbDialog = [[FBDialog alloc] initWithURL:dialogURL
                                       params:params
                              isViewInvisible:invisible
                         frictionlessSettings:_frictionlessRequestSettings
                                     delegate:delegate];
    
    _fbDialog.forcedHidden = hidden;
    [_fbDialog show];
}

- (BOOL)isFrictionlessRequestsEnabled {
    return _frictionlessRequestSettings.enabled;
}

- (void)enableFrictionlessRequests {
    [_frictionlessRequestSettings enableWithFacebook:self];
}

- (void)reloadFrictionlessRecipientCache {
    [_frictionlessRequestSettings reloadRecipientCacheWithFacebook:self];
}

- (BOOL)isFrictionlessEnabledForRecipient:(NSString*)fbid {
    return [_frictionlessRequestSettings isFrictionlessEnabledForRecipient:fbid];
}

- (BOOL)isFrictionlessEnabledForRecipients:(NSArray*)fbids {
    return [_frictionlessRequestSettings isFrictionlessEnabledForRecipients:fbids];
}

#pragma mark - FBRequestDelegate Methods

+ (BOOL)automaticallyNotifiesObserversForKey:(NSString *)key {
    // these properties must manually notify for KVO    
    if ([key isEqualToString:FBaccessTokenPropertyName] ||
        [key isEqualToString:FBexpirationDatePropertyName]) {
        return NO;
    } else {
        return [super automaticallyNotifiesObserversForKey:key];
    }
}

@end
