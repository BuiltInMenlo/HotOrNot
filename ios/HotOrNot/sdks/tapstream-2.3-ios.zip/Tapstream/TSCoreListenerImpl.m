#import "TSCoreListenerImpl.h"

@implementation TSCoreListenerImpl

- (void)reportOperation:(NSString *)op
{
}

- (void)reportOperation:(NSString *)op arg:(NSString *)arg
{
}

@end