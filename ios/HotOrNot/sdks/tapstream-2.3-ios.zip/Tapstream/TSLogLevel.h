#pragma once

typedef enum _TSLoggingLevel
{
	kTSLoggingInfo = 0,
	kTSLoggingWarn,
	kTSLoggingError

} TSLoggingLevel;
