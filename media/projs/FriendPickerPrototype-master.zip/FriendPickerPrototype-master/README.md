FriendPickerPrototype
========================

## "Live" Friend Searching
Friend Picker Prototype for live Facebook friend searching.