//
//  PathlikeSliderController.h
//  FeaturesExample
//

#import <UIKit/UIKit.h>
#import "IIViewDeckController.h"

@interface PathlikeSliderController : IIViewDeckController

@end
