//
//  ModalViewController.h
//  MultiViewDeckExample
//
//  Created by Tom Adriaenssen on 10/05/12.
//  Copyright (c) 2012 Tom Adriaenssen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController

@end
