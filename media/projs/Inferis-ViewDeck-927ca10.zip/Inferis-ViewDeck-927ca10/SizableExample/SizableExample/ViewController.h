//
//  ViewController.h
//  SizableExample
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIView* containerView;

- (IBAction)zoomPressed:(id)sender;

@end
