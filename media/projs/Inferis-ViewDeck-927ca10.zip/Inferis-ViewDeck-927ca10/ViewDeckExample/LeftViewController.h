//
//  LeftViewController.h
//  ViewDeckExample
//


#import <UIKit/UIKit.h>

@interface LeftViewController : UITableViewController

@end
