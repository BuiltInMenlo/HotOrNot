//
//  ViewController.h
//  ViewDeckExample
//


#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController

@property (nonatomic, retain) UIPopoverController* popoverController;
@end
