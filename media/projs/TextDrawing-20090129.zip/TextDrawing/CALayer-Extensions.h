//
//  CALayer-Extensions.h
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/23/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

@interface CALayer (OOExtensions)
- (CALayer *)rootLayer;
- (void)logGeometry;
- (void)logLocalGeometry;
- (void)logAncestorGeometry;
- (void)appendGeometry:(NSMutableString *)str depth:(unsigned)depth;
- (void)appendLocalGeometry:(NSMutableString *)str;
@end

