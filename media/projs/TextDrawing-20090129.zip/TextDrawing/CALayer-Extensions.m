//
//  CALayer-Extensions.m
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/23/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import "CALayer-Extensions.h"

@implementation CALayer (OOExtensions)
- (CALayer *)rootLayer;
{
    CALayer *parent = self, *layer;
    do {
        layer = parent;
        parent = parent.superlayer;
    } while (parent);
    return layer;
}
static void _writeString(NSString *str)
{
    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
    fwrite([data bytes], [data length], 1, stderr);
    fputc('\n', stderr);
}

- (void)logGeometry;
{
    NSMutableString *str = [NSMutableString string];
    [self appendGeometry:str depth:0];
    _writeString(str);
}

- (void)logLocalGeometry;
{
    NSMutableString *str = [NSMutableString string];
    [self appendLocalGeometry:str];
    _writeString(str);
}

- (void)logAncestorGeometry;
{
    NSMutableString *str = [NSMutableString string];
    CALayer *layer = self;
    while (layer) {
        [layer appendLocalGeometry:str];
        [str appendString:@"\n"];
        layer = layer.superlayer;
    }
    _writeString(str);
}

- (void)appendGeometry:(NSMutableString *)str depth:(unsigned)depth;
{
    unsigned i;
    for (i = 0; i < depth; i++)
        [str appendString:@"  "];
    
    [self appendLocalGeometry:str];
    
    NSArray *sublayers = self.sublayers;
    if ([sublayers count] > 0) {
        [str appendString:@" {\n"];
        for (CALayer *l in sublayers)
            [l appendGeometry:str depth:depth+1];
        for (i = 0; i < depth; i++)
            [str appendString:@"  "];
        [str appendString:@"}\n"];
    } else {
        [str appendString:@"\n"];
        
    }
}

- (void)appendLocalGeometry:(NSMutableString *)str;
{    
    NSString *name = self.name;
    if ([name length] > 0)
        [str appendFormat:@"%@=", name];
    
    [str appendFormat:@"<%@:%p>", NSStringFromClass([self class]), self];
    id delegate = self.delegate;
    if (delegate)
        [str appendFormat:@" %@", [delegate description]];
    
    [str appendFormat:@" b:%@", NSStringFromRect(NSRectFromCGRect(self.bounds))];
    
    NSPoint p = NSPointFromCGPoint(self.anchorPoint);
    if (!NSEqualPoints(p, NSZeroPoint))
        [str appendFormat:@" anchor:%@", NSStringFromPoint(p)];
    
    p = NSPointFromCGPoint(self.position);
    if (!NSEqualPoints(p, NSPointFromCGPoint(self.frame.origin)))
        [str appendFormat:@" position:%@", NSStringFromPoint(p)];
    
    if (self.zPosition != 0.0)
        [str appendFormat:@" z:%g", self.zPosition];
    
    if (self.hidden)
        [str appendString:@" HIDDEN"];
    if (!self.isDoubleSided)
        [str appendString:@" SINGLE-SIDED"];
    if (self.masksToBounds)
        [str appendString:@" masks"];
    
    CALayer *mask = self.mask;
    if (mask)
        [str appendFormat:@" mask:%@", [mask description]];
    
    id contents = self.contents;
    if (contents) {
        [str appendFormat:@" contents:%@", contents];
        [str appendFormat:@" grav:%@", self.contentsGravity];
    }
    
    NSString *filter;
    if (![(filter = self.minificationFilter) isEqualToString:kCAFilterLinear])
        [str appendFormat:@" min-filter:%@", filter];
    if (![(filter = self.magnificationFilter) isEqualToString:kCAFilterLinear])
        [str appendFormat:@" mag-filter:%@", filter];
    
    if (self.opaque)
        [str appendString:@" opaque"];
    if (self.needsDisplayOnBoundsChange)
        [str appendFormat:@" needsDisplayOnBoundsChange"];
    if (self.edgeAntialiasingMask != 0)
        [str appendFormat:@" edge:%d", self.edgeAntialiasingMask];
    
    CGColorRef bg = self.backgroundColor;
    if (bg)
        [str appendFormat:@" bg:%@", [(id)CFCopyDescription(bg) autorelease]];
    
    if (self.cornerRadius != 0)
        [str appendFormat:@" corner:%g", self.cornerRadius];
    if (self.borderWidth != 0) {
        [str appendFormat:@" borderWidth:%g", self.borderWidth];
        if (self.borderColor != 0)
            [str appendFormat:@" borderColor:%@", [(id)CFCopyDescription(self.borderColor) autorelease]];
    }
    if (self.opacity != 1)
        [str appendFormat:@" opacity:%g", self.opacity];
    
    if (self.compositingFilter)
        [str appendFormat:@" compositingFilter:%@", self.compositingFilter];
    if ([self.filters count] > 0)
        [str appendFormat:@" filters:%@", self.filters];
    if ([self.backgroundFilters count] > 0)
        [str appendFormat:@" backgroundFilters:%@", self.backgroundFilters];
    
    if (self.shadowOpacity != 0) {
        [str appendFormat:@" shadowOpacity:%g", self.shadowOpacity];
        if (self.shadowColor)
            [str appendFormat:@" shadowColor:%@", [(id)CFCopyDescription(self.shadowColor) autorelease]];
        if (!CGSizeEqualToSize(self.shadowOffset, CGSizeMake(0,-3)))
            [str appendFormat:@" shadowOffset:%@", NSStringFromSize(NSSizeFromCGSize(self.shadowOffset))];
        if (self.shadowRadius != 3)
            [str appendFormat:@" shadowRadius:%g", self.shadowRadius];
    }
    
    if (self.autoresizingMask != 0)
        [str appendFormat:@" autoresizingMask:%d", self.autoresizingMask];
    
    if (self.layoutManager)
        [str appendFormat:@" layout:%@", [self.layoutManager description]];
    
    
    CATransform3D transform = self.transform;
    if (!CATransform3DIsIdentity(transform)) {
        [str appendFormat:@" xform:[%g %g %g %g; %g %g %g %g; %g %g %g %g; %g %g %g %g]",
         transform.m11, transform.m12, transform.m13, transform.m14,
         transform.m21, transform.m22, transform.m23, transform.m24,
         transform.m31, transform.m32, transform.m33, transform.m34,
         transform.m41, transform.m42, transform.m43, transform.m44];
    }
    
    transform = self.sublayerTransform;
    if (!CATransform3DIsIdentity(transform)) {
        [str appendFormat:@" sublayer:[%g %g %g %g; %g %g %g %g; %g %g %g %g; %g %g %g %g]",
         transform.m11, transform.m12, transform.m13, transform.m14,
         transform.m21, transform.m22, transform.m23, transform.m24,
         transform.m31, transform.m32, transform.m33, transform.m34,
         transform.m41, transform.m42, transform.m43, transform.m44];
    }
}

@end

