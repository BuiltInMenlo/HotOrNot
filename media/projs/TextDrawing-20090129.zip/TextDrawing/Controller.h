//
//  Controller.h
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/22/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class OOFlippedLayerView;

@interface Controller : NSObject
{
    IBOutlet OOFlippedLayerView *_view;
    NSUInteger _testCount;
}

- (IBAction)logGeometry:(id)sender;

@end
