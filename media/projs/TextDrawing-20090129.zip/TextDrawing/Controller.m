//
//  Controller.m
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/22/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import "Controller.h"

#import "OOFlippedLayerView.h"
#import <objc/message.h>
#import "CALayer-Extensions.h"
#import "SimpleStringDrawingLayer.h"
#import "TextSystemDrawingLayer.h"
#import "SimpleStringIntoBitmapLayer.h"

@implementation Controller

static NSString * const TestString = @"Wag fly\nqux Ape";
static const NSSize TextTestSize = {80, 48};
static CGFloat TextGap = 8;
static NSFont *TestFont = nil;

NSColor *BackgroundColor = nil;
CGColorRef BackgroundColorRef = NULL;

- (void)_addTest:(NSString *)name;
{
    NSTextField *label = [[NSTextField alloc] init];
    [label setStringValue:name];
    [label setEditable:NO];
    [label setBezeled:NO];
    [label setBackgroundColor:[NSColor controlBackgroundColor]];
    [label sizeToFit];
    [label setFrameRotation:-90];
    
    NSRect bounds = _view.bounds;
    NSRect testRect = NSMakeRect(TextGap + NSMinX(bounds) + (TextTestSize.width + TextGap) * _testCount, TextGap, TextTestSize.width, TextTestSize.height);
    testRect = NSIntegralRect(testRect); // hacky
    [label setFrameOrigin:NSMakePoint(NSMidX(testRect), NSMaxY(testRect))];
    [_view addSubview:label];
    
    NSMutableString *selName = [NSMutableString stringWithFormat:@"_test_%@:", name];
    [selName replaceOccurrencesOfString:@" " withString:@"_" options:0 range:NSMakeRange(0, [selName length])];
    
    SEL sel = NSSelectorFromString(selName);
    void (*imp)(id self, SEL _cmd, NSRect r) = (typeof(imp))[self methodForSelector:sel];
    imp(self, sel, testRect);
    
    _testCount++;
}

- (void)_test_NSTextView:(NSRect)frame;
{
    NSTextView *textView = [[NSTextView alloc] initWithFrame:frame];

    // Drop text padding that we normally get to look like the other cases.
    [textView setTextContainerInset:NSZeroSize];
    [textView.textContainer setLineFragmentPadding:0];
    textView.backgroundColor = BackgroundColor;
    
    [textView setString:TestString];
    [textView setFont:TestFont];
    [_view addSubview:textView];
}

- (void)_test_CATextLayer:(NSRect)frame;
{
    CATextLayer *layer = [CATextLayer layer];
    layer.string = TestString;
    layer.font = TestFont;
    layer.fontSize = [TestFont pointSize];
    layer.anchorPoint = CGPointMake(0, 0);
    layer.backgroundColor = BackgroundColorRef;
    layer.foregroundColor = CGColorGetConstantColor(kCGColorBlack);
    layer.position = CGPointMake(frame.origin.x, frame.origin.y);
    layer.bounds = CGRectMake(0, 0, frame.size.width, frame.size.height);
    layer.needsDisplayOnBoundsChange = YES;

    // Set up a flipped transform for the contents
    CGRect bounds = layer.bounds;
    CATransform3D translate = CATransform3DMakeTranslation(0, -bounds.size.height, 0);
    CATransform3D scale = CATransform3DMakeScale(1.0, -1.0, 1.0);
    CATransform3D transform = CATransform3DConcat(translate, scale);
    layer.transform = transform;

    [_view.flippedLayer addSublayer:layer];
}

- (void)_test_Simple_String_Drawing_Layer:(NSRect)frame;
{
    SimpleStringDrawingLayer *layer = [SimpleStringDrawingLayer layer];
    layer.anchorPoint = CGPointMake(0, 0);
    layer.position = CGPointMake(frame.origin.x, frame.origin.y);
    layer.bounds = CGRectMake(0, 0, frame.size.width, frame.size.height);
    [layer setNeedsDisplay];
    layer.needsDisplayOnBoundsChange = YES;
    
    layer.string = TestString;
    layer.font = TestFont;
    
    [_view.flippedLayer addSublayer:layer];
}

- (void)_test_Simple_String_Into_Bitmap_Layer:(NSRect)frame;
{
    SimpleStringIntoBitmapLayer *layer = [SimpleStringIntoBitmapLayer layer];
    layer.anchorPoint = CGPointMake(0, 0);
    layer.position = CGPointMake(frame.origin.x, frame.origin.y);
    layer.bounds = CGRectMake(0, 0, frame.size.width, frame.size.height);
    [layer setNeedsDisplay];
    layer.needsDisplayOnBoundsChange = YES;
    
    layer.string = TestString;
    layer.font = TestFont;
    
    [_view.flippedLayer addSublayer:layer];
}

- (void)_test_Text_System_Drawing_Layer:(NSRect)frame;
{
    CALayer *layer = [[[TextSystemDrawingLayer alloc] initWithString:TestString font:TestFont size:TextTestSize] autorelease];
    layer.anchorPoint = CGPointMake(0, 0);
    layer.position = CGPointMake(frame.origin.x, frame.origin.y);
    layer.bounds = CGRectMake(0, 0, frame.size.width, frame.size.height);
    [layer setNeedsDisplay];
    layer.needsDisplayOnBoundsChange = YES;
    
    [_view.flippedLayer addSublayer:layer];
}

static void _cleanLayer(CALayer *layer)
{
    layer.edgeAntialiasingMask = 0;
    layer.contentsGravity = kCAGravityLeft;
    for (CALayer *child in layer.sublayers)
        _cleanLayer(child);
}

- (void)applicationDidFinishLaunching:(NSNotification *)note;
{
    TestFont = [NSFont fontWithName:@"LucidaGrande" size:18.0];
    NSLog(@"TestFont = %@", TestFont);
    
    BackgroundColor = [[NSColor colorWithCalibratedRed:0.8 green:0.8 blue:0.8 alpha:1.0] retain];
    BackgroundColorRef = CGColorCreateGenericRGB(0.8, 0.8, 0.8, 1.0);

    [self _addTest:@"CATextLayer"];
    [self _addTest:@"NSTextView"];
    [self _addTest:@"Text System Drawing Layer"];
    [self _addTest:@"Simple String Drawing Layer"];
    [self _addTest:@"Simple String Into Bitmap Layer"];
    
    _cleanLayer(_view.layer.rootLayer);
}

- (IBAction)logGeometry:(id)sender;
{
    [_view.layer.rootLayer logGeometry];
}

@end
