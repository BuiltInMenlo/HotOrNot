// Copyright 2008-2009 Omni Development, Inc.  All rights reserved.

#import <AppKit/NSView.h>

@class CALayer;

@interface OOFlippedLayerView : NSView
{
@private
    CALayer *_flippedLayer;
}

@property(nonatomic,readonly) CALayer *flippedLayer;

// Subclass API
- (void)updateLayerBackgroundColor;

@end
