// Copyright 2008-2009 Omni Development, Inc.  All rights reserved.

#import "OOFlippedLayerView.h"

#import "assertions.h"

//RCS_ID("$Header: svn+ssh://source.omnigroup.com/Source/svn/Omni/trunk/Staff/bungi/Radar/CoreAnimation/TextDrawing/OOFlippedLayerView.m 107955 2009-01-22 22:47:57Z bungi $")

@interface OOFlippedLayerView (/*Private*/)
- (void)_updateFlippedLayerTransform;
@end

@implementation OOFlippedLayerView

- (id)initWithFrame:(NSRect)frameRect;
{
    if (!(self = [super initWithFrame:frameRect]))
        return nil;
    
    // We do not set wantsLayer here. If we are getting loaded from nib, it would get cleared anyway.
    // This layer has zero size and is just a transform device, not a rendering device.
    _flippedLayer = [[CALayer alloc] init];
    _flippedLayer.name = @"flipped";
    _flippedLayer.anchorPoint = CGPointMake(0, 0);
    _flippedLayer.bounds = CGRectMake(0, 0, 0, 0);
    _flippedLayer.edgeAntialiasingMask = 0;

    return self;
}

- (void)dealloc;
{
    OBASSERT(_flippedLayer.delegate == nil);
    [_flippedLayer release];
    [super dealloc];
}

#pragma mark NSView subclass

- (BOOL)isFlipped;
{
    return YES;
}

- (BOOL)isOpaque;
{
    return YES;
}

- (void)setFrameSize:(NSSize)size;
{
    [super setFrameSize:size];
    [self _updateFlippedLayerTransform];
}

- (void)viewDidMoveToSuperview;
{
    OBPRECONDITION(!self.superview || self.enclosingScrollView); // OOFlippedLayerView wants to live in a scroll view.
    
    [super viewDidMoveToSuperview];
    [self _updateFlippedLayerTransform];
}

- (void)viewDidMoveToWindow;
{
    [super viewDidMoveToWindow];
    [self _updateFlippedLayerTransform];
}

- (void)setLayer:(CALayer *)layer;
{
    [super setLayer:layer];
    
    // The CoreAnimation graphics space is not flipped, but we need a flipped coordinate system.  We cannot simply set up a flipped sublayerTransform in the view's layer since NSView owns that layer and needs to in order to managed adding subviews correctly (like our field editor). Instead, we add a special flipped layer in which we will do this.
    if (layer) {
        layer.opaque = YES;
        layer.edgeAntialiasingMask = 0;
        
        OBASSERT(_flippedLayer);
        if (_flippedLayer.superlayer != layer)
            [layer addSublayer:_flippedLayer];
        
        NSScrollView *scrollView = self.enclosingScrollView;
        scrollView.wantsLayer = YES;
        
        OBASSERT(scrollView.layer);
        scrollView.layer.edgeAntialiasingMask = 0;
        
        NSClipView *clipView = scrollView.contentView;
        OBASSERT(clipView.layer);
        clipView.layer.edgeAntialiasingMask = 0;
        
        [self updateLayerBackgroundColor];
        [self _updateFlippedLayerTransform];
    } else {
        [_flippedLayer removeFromSuperlayer];
    }
}

#pragma mark KVC

- (CALayer *)flippedLayer;
{
    OBPRECONDITION(_flippedLayer);
    return _flippedLayer;
}

#pragma mark Subclass API

- (void)updateLayerBackgroundColor;
{
    // Nothing
}

#pragma mark Private

// Re-establish the flipped layer within our root layer
- (void)_updateFlippedLayerTransform;
{
    [CATransaction begin];
    [CATransaction setValue:(id)kCFBooleanTrue forKey:kCATransactionDisableActions];
    {
        NSRect bounds = self.bounds;
        
        // Update the transform based on our current size
        CATransform3D translate = CATransform3DMakeTranslation(0, -bounds.size.height, 0);
        CATransform3D scale = CATransform3DMakeScale(1.0, -1.0, 1.0);
        CATransform3D transform = CATransform3DConcat(translate, scale);
        _flippedLayer.sublayerTransform = transform;
    }
    [CATransaction commit];
}

@end
