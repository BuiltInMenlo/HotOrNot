//
//  SimpleStringDrawingLayer.h
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/23/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import <QuartzCore/CALayer.h>

@interface SimpleStringDrawingLayer : CALayer
{
    NSString *_string;
    NSFont *_font;
}
@property(nonatomic,copy) NSString *string;
@property(nonatomic,retain) NSFont *font;
@end
