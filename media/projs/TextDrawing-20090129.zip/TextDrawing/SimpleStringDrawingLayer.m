//
//  SimpleStringDrawingLayer.m
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/23/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import "SimpleStringDrawingLayer.h"

@implementation SimpleStringDrawingLayer

- init;
{
    if (!(self = [super init]))
        return nil;
    
    self.font = [NSFont userFontOfSize:[NSFont systemFontSizeForControlSize:NSRegularControlSize]];
    [self setNeedsLayout];
    return self;
}

- (void)setString:(NSString *)string;
{
    if ([_string isEqualToString:string] || (!_string && !string))
        return;
    [_string release];
    _string = [string copy];
    [self setNeedsDisplay];
}
- (void)setFont:(NSFont *)font;
{
    if (_font == font)
        return;
    [_font release];
    _font = [font retain];
    [self setNeedsDisplay];
}
@synthesize string=_string, font=_font;

- (void)layoutSublayers;
{
    [super layoutSublayers];
    
    // Set up a flipped transform for the contents, since we drew into our content with flipped=NO (to avoid the apparent vertical antialiasing bug in that case).
    CGRect bounds = self.bounds;
    CATransform3D translate = CATransform3DMakeTranslation(0, -bounds.size.height, 0);
    CATransform3D scale = CATransform3DMakeScale(1.0, -1.0, 1.0);
    CATransform3D transform = CATransform3DConcat(translate, scale);
    self.transform = transform;
}


- (void)drawInContext:(CGContextRef)ctx;
{
    CGContextSetFillColorWithColor(ctx, BackgroundColorRef);
    CGContextFillRect(ctx, self.bounds);
    
    NSGraphicsContext *gc = [NSGraphicsContext graphicsContextWithGraphicsPort:ctx flipped:NO];
    [NSGraphicsContext saveGraphicsState];
    [NSGraphicsContext setCurrentContext:gc];
    {
        NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:_font, NSFontAttributeName, nil];
        [_string drawWithRect:NSRectFromCGRect(self.bounds) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes];
    }
    [NSGraphicsContext restoreGraphicsState];
}

@end

