//
//  SimpleStringIntoBitmapLayer.h
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/29/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface SimpleStringIntoBitmapLayer : CALayer
{
    NSString *_string;
    NSFont *_font;
}
@property(nonatomic,copy) NSString *string;
@property(nonatomic,retain) NSFont *font;
@end
