//
//  SimpleStringIntoBitmapLayer.m
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/29/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import "SimpleStringIntoBitmapLayer.h"

#import "assertions.h"

@implementation SimpleStringIntoBitmapLayer

- init;
{
    if (!(self = [super init]))
        return nil;
    
    self.font = [NSFont userFontOfSize:[NSFont systemFontSizeForControlSize:NSRegularControlSize]];
    [self setNeedsLayout];
    return self;
}

- (void)setString:(NSString *)string;
{
    if ([_string isEqualToString:string] || (!_string && !string))
        return;
    [_string release];
    _string = [string copy];
    [self setNeedsDisplay];
}
- (void)setFont:(NSFont *)font;
{
    if (_font == font)
        return;
    [_font release];
    _font = [font retain];
    [self setNeedsDisplay];
}
@synthesize string=_string, font=_font;

- (void)display;
{
    // Try rendering into a CGBitmapContext; getting the LCD antialiasing is the hard part...
    
    CGRect bounds = self.bounds;
    OBASSERT(bounds.origin.x == 0); // Not handling this; simple!
    OBASSERT(bounds.origin.y == 0);
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateWithName(kCGColorSpaceGenericRGB);
    CGContextRef ctx = CGBitmapContextCreate(NULL, bounds.size.width, bounds.size.height, 8/*bitsPerComponent*/, 4*bounds.size.width, colorSpace, kCGImageAlphaPremultipliedFirst|kCGBitmapByteOrder32Host);
    CFRelease(colorSpace);
    
    if (!ctx) {
        OBASSERT_NOT_REACHED("Bad context settings?");
        self.contents = nil;
        return;
    }
    
    NSGraphicsContext *gc = [NSGraphicsContext graphicsContextWithGraphicsPort:ctx flipped:YES];
    [NSGraphicsContext saveGraphicsState];
    [NSGraphicsContext setCurrentContext:gc];
    {
        CGContextSetFillColorWithColor(ctx, BackgroundColorRef);
        CGContextFillRect(ctx, bounds);

        NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:_font, NSFontAttributeName, nil];
        [_string drawWithRect:NSRectFromCGRect(bounds) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes];
    }
    [NSGraphicsContext restoreGraphicsState];
    
    CGImageRef image = CGBitmapContextCreateImage(ctx);
    CFRelease(ctx);
    
    self.contents = (id)image;
    if (image)
        CFRelease(image);
}

@end
