//
//  TextSystemDrawingLayer.h
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/23/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import <QuartzCore/CALayer.h>

@interface TextSystemDrawingLayer : CALayer
{
    NSTextStorage *_textStorage;
    NSLayoutManager *_layoutManager;
    NSTextContainer *_textContainer;
}

- initWithString:(NSString *)string font:(NSFont *)font size:(NSSize)size;

@end

