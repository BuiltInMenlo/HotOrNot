//
//  TextSystemDrawingLayer.m
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/23/09.
//  Copyright 2009 The Omni Group. All rights reserved.
//

#import "TextSystemDrawingLayer.h"

#import "assertions.h"

@implementation TextSystemDrawingLayer

static void _forceLayoutForCharacterRange(NSLayoutManager *self, NSRange characterRange)
{
    NSRange glyphRange = [self glyphRangeForCharacterRange:characterRange actualCharacterRange:NULL];
    
    unsigned int location = glyphRange.location;
    while (location < NSMaxRange(glyphRange)) {
        NSRange effectiveRange;
        [self textContainerForGlyphAtIndex:location effectiveRange:&effectiveRange];
        location = NSMaxRange(effectiveRange);
    }
}

static void _forceLayout(NSLayoutManager *self)
{
    NSTextStorage *textStorage = [self textStorage];
    unsigned int characterCount = [textStorage length];
    _forceLayoutForCharacterRange(self, (NSRange){0, characterCount});
}

- initWithString:(NSString *)string font:(NSFont *)font size:(NSSize)size;
{
    OBPRECONDITION(string);
    OBPRECONDITION(font);
    OBPRECONDITION(size.width > 0);
    OBPRECONDITION(size.height > 0);
    
    if (!(self = [super init]))
        return nil;
    
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
    _textStorage = [[NSTextStorage alloc] initWithString:string attributes:attributes];
    
    _layoutManager = [[NSLayoutManager alloc] init];
    [_layoutManager setBackgroundLayoutEnabled:NO];
    [_layoutManager setDelegate:self];
    
    _textContainer = [[NSTextContainer alloc] initWithContainerSize:size];
    [_textContainer setLineFragmentPadding:0];
    [_layoutManager addTextContainer:_textContainer];
    
    [_textStorage addLayoutManager:_layoutManager];
    
    _forceLayout(_layoutManager);
    
    return self;
}

- (void)layoutSublayers;
{
    [super layoutSublayers];
    
    // Set up a flipped transform for the contents, since we drew into our content with flipped=NO (to avoid the apparent vertical antialiasing bug in that case).
    CGRect bounds = self.bounds;
    CATransform3D translate = CATransform3DMakeTranslation(0, -bounds.size.height, 0);
    CATransform3D scale = CATransform3DMakeScale(1.0, -1.0, 1.0);
    CATransform3D transform = CATransform3DConcat(translate, scale);
    self.transform = transform;
}

- (void)drawInContext:(CGContextRef)ctx;
{
    CGContextSetFillColorWithColor(ctx, BackgroundColorRef);
    CGContextFillRect(ctx, self.bounds);
    
    NSGraphicsContext *gc = [NSGraphicsContext graphicsContextWithGraphicsPort:ctx flipped:YES];
    [NSGraphicsContext saveGraphicsState];
    [NSGraphicsContext setCurrentContext:gc];
    {
        CGRect bounds = self.bounds;
        CGAffineTransform translate = CGAffineTransformMakeTranslation(0, -bounds.size.height);
        CGAffineTransform scale = CGAffineTransformMakeScale(1.0, -1.0);
        CGAffineTransform transform = CGAffineTransformConcat(translate, scale);
        CGContextConcatCTM(ctx, transform);

        NSRange glyphRange = [_layoutManager glyphRangeForTextContainer:_textContainer];
        [_layoutManager drawGlyphsForGlyphRange:glyphRange atPoint:NSZeroPoint];
    }
    [NSGraphicsContext restoreGraphicsState];
}

@end
