//
//  main.m
//  TextDrawing
//
//  Created by Timothy J. Wood on 1/22/09.
//  Copyright The Omni Group 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
