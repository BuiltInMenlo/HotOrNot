//
//  NBPhoneMetaDataGenerator.h
//  libPhoneNumber
//
//  Created by NHN Corp. Last Edited by BAND dev team (band_dev@nhn.com)
//

#import <Foundation/Foundation.h>

@interface NBPhoneMetaDataGenerator : NSObject

- (void)generateMetadataClasses;

@end
