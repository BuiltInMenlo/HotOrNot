//
//  FirstViewController.h
//  RumexCustomTabBar
//
//  Created by Oliver Farago on 18/11/2010.
//  Copyright 2010 Rumex IT. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FirstViewController : UIViewController {

}

- (IBAction)btnPressHide:(id)sender;
- (IBAction)btnPressShow:(id)sender;

@end
