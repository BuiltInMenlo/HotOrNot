/**********************************************
 
 Copyright 2011 Kik Interactive Inc.
 
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 
 **********************************************/


#import "SketchAppDelegate.h"

#import "SketchViewController.h"

@implementation SketchAppDelegate


@synthesize window = _window;
@synthesize viewController = _viewController;
@synthesize currentConversationID = _currentConversationID;


/**
 * Simple method that will handle the KikAPIData object we are launched with.
 * @param data KikAPIData object containing the context we were launched with
 * @return YES if we know how to handle it, NO otherwise
 */
- (BOOL)handleKikAPIData:(KikAPIData *)data
{
	if ( data == nil ) return NO;
	if ( data.type == KikAPIDataTypeNotKik ) return NO;
	
	if ( data.type == KikAPIDataTypePick ) {
		self.currentConversationID = data.conversationID;
	}
	else {
		[self.viewController loadFromURI:data.message.fileUrl];
		self.currentConversationID = data.conversationID;
	}
	
	return YES;
}


- (void)applicationDidFinishLaunching:(UIApplication *)application
{
	// We need to register as a Kik application before we can do anything with the API
	[KikAPIClient registerAsKikPluginWithAppID:@"com.kik.demo.sketch" withHomepageURI:@"http://kik.com" addAppButton:YES];
	
	// The remainder is just common app delegate behaviour
	// self.window.rootViewController = self.viewController; // lets do it the way iOS 3 supports :)
	[self.window addSubview:self.viewController.view];
	self.viewController.delegate = self;
	[self.window makeKeyAndVisible];
}

/**
 * This method is called upon being launched with a URL in iOS 4
 */
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    // Attempt to handle the API data retrieved from the URL handler
	return [self handleKikAPIData:[KikAPIClient handleOpenURL:url sourceApplication:sourceApplication annotation:annotation]];
}

/**
 * This method is called upon being launched with a URL in iOS 3
 */
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    // Attempt to handle the API data retrieved from the URL handler
	return [self handleKikAPIData:[KikAPIClient handleOpenURL:url]];
}


- (void)dealloc
{
	[_window release];
	[_viewController release];
	[_currentConversationID release];
    [super dealloc];
}


#pragma mark -
#pragma mark Sketch View Controller Delegate

/**
 * When our sketch view controller asks to "save" the image, we'll kik it :)
 */
- (void)saveSketchImage:(UIImage *)image
{
	// Save it to a file first
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"temp_picture"];
	
	// If our temp image exists, delete it
	if ( [[NSFileManager defaultManager] fileExistsAtPath:filePath] ) {
		[[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
	}
	[UIImagePNGRepresentation(image) writeToFile:filePath atomically:YES]; // save as PNG
	
	// Now construct a Kik message and send it
	KikAPIMessage *message = [KikAPIMessage message];
	[message setPreviewFromImage:image];
	
	// We could set a title and description for our for our message, however this demo app doesn't have any relevant
	// information to be used as either the title or description.
	//message.title = @"My Title";
	//message.description = @"My message description";
	
	//Set Uri's which will allow iphone and android users without the application to get it.
	message.androidURIs = [NSArray arrayWithObject:@"http://kik.com/api-demo/sketch/android/"];
	message.iphoneURIs = [NSArray arrayWithObject:@"http://kik.com/api-demo/sketch/iphone/"];
	//If all else fails, this is where the user will be directed to.
	message.genericURIs = [NSArray arrayWithObject:@"http://kik.com/api-demo/sketch/other/"];
	
	message.filePath = filePath; // We want to upload the image file so that it can be viewed full size on the other end
	NSString *convoID = [[self.currentConversationID copy] autorelease]; // Keep the conversation id
	self.currentConversationID = nil; // ...and nullify the property *before* sending the message (since on iOS3 it will quit the app)
	[KikAPIClient sendMessage:message toConversation:convoID]; // Kik it
}

@end
