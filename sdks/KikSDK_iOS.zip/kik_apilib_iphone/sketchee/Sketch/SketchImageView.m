/**********************************************
 
 Copyright 2011 Kik Interactive Inc.
 
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 
 **********************************************/


#import "SketchImageView.h"


@implementation SketchImageView

@synthesize lineWidth = _lineWidth;

/**
 * Setter for our brush color (for now we'll only use black for 'erase', and white for 'draw',
 * but this can be changed to pretty much anything.
 */
- (void)setBrushColorWithRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue
{
	_red = red;
	_green = green;
	_blue = blue;
	_alpha = 1.0;
}


/**
 * Overriden handler for "touchesBegan".
 * For simplicity we will handle only one touch at a time.
 */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [touches anyObject];
	_previousPoint = [touch locationInView:self];
	_touchMoved = NO;
}


/**
 * When touch is moved, we set a corresponding flag to prevent unnecessary redrawing when touches end, 
 * then perform the usual contextual line drawing from the previous touch point to the current
 * one.
 */
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [touches anyObject];
	_touchMoved = YES;
	CGPoint point = [touch locationInView:self];
	
	// Draw as usual in the current context
	UIGraphicsBeginImageContext(self.frame.size);
	[self.image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
	CGContextRef c = UIGraphicsGetCurrentContext();
	CGContextSetLineCap(c, kCGLineCapRound);
	CGContextSetLineWidth(c, _lineWidth);
	CGContextSetRGBStrokeColor(c, _red, _green, _blue, _alpha);
	CGContextBeginPath(c);
	CGContextMoveToPoint(c, _previousPoint.x, _previousPoint.y);
	CGContextAddLineToPoint(c, point.x, point.y);
	CGContextStrokePath(c);
	self.image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	// Save current point as previous point
	_previousPoint = point;
}


/**
 * If touches ended, and none of the touches moved, we draw a dot, mimicking
 * the behaviour of a real brush.
 */
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	if ( !_touchMoved ) {
		UIGraphicsBeginImageContext(self.frame.size);
		[self.image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
		CGContextRef c = UIGraphicsGetCurrentContext();
		CGContextSetLineCap(c, kCGLineCapRound);
		CGContextSetLineWidth(c, _lineWidth);
		CGContextSetRGBStrokeColor(c, _red, _green, _blue, _alpha);
		CGContextMoveToPoint(c, _previousPoint.x, _previousPoint.y);
		CGContextAddLineToPoint(c, _previousPoint.x, _previousPoint.y);
		CGContextStrokePath(c);
		CGContextFlush(c);
		self.image = UIGraphicsGetImageFromCurrentImageContext();
		UIGraphicsEndImageContext();
	}
}


/**
 * Clear by simply filling the view with all black.
 */
- (void)clear
{
	UIGraphicsBeginImageContext(self.frame.size);
	CGContextRef c = UIGraphicsGetCurrentContext();
	CGContextSetRGBStrokeColor(c, _red, _green, _blue, _alpha);
	CGContextSetRGBFillColor(c, 0.0, 0.0, 0.0, 1.0);
	CGContextFillRect(c, CGRectMake(0, 0, self.frame.size.width, self.frame.size.height));
	self.image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
}
	


@end
