/**********************************************
 
 Copyright 2011 Kik Interactive Inc.
 
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 
 **********************************************/


#import <UIKit/UIKit.h>
#import "SketchImageView.h"


/**
 * To avoid 'spaghetti dependencies', we'll create a simple delegate
 * protocol for the sketch controller, and implement it in our main app delegate
 */
@protocol SketchViewControllerDelegate <NSObject>
@optional
- (void)saveSketchImage:(UIImage *)image;
@end


@interface SketchViewController : UIViewController {
	IBOutlet SketchImageView *_sketch;
	IBOutlet UISegmentedControl *_colorPicker;
	id < SketchViewControllerDelegate > _delegate;
	IBOutlet UIActivityIndicatorView *_activityView;
}

@property (nonatomic, assign) id < SketchViewControllerDelegate > delegate;

/**
 * IBActions for color picker (segmented control), clear and kik (save) buttons
 */
- (IBAction)colorChanged:(UISegmentedControl *)sender;
- (IBAction)clearButtonClick:(id)sender;
- (IBAction)kikButtonClick:(id)sender;

- (void)loadFromURI:(NSString *)uriString;

- (void)setLoadedImage:(UIImage *)image;

@end
