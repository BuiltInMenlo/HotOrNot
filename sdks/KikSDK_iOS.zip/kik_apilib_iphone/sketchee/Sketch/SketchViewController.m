/**********************************************
 
 Copyright 2011 Kik Interactive Inc.
 
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
 
 http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 
 **********************************************/


#import "SketchViewController.h"

@implementation SketchViewController

@synthesize delegate = _delegate;

- (void)dealloc
{
	[_sketch release];
	[_colorPicker release];
	[_activityView release];
    [super dealloc];
}


#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
	[_sketch clear];
	[self colorChanged:_colorPicker];
}

- (void)viewDidUnload
{
	[_sketch release];
	_sketch = nil;
	[_colorPicker release];
	_colorPicker = nil;
	[_activityView release];
	_activityView = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

/**
 * Starts spinner animation and runs the image loading routine on a timer.
 */
- (void)loadFromURI:(NSString *)uriString
{
	[_activityView startAnimating];
	[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(loadImageOnTimer:) userInfo:uriString repeats:NO];
}

/**
 * Sync image loading: for simplicity of code (and small size of images) we used a convenience method of NSData, however for
 * large files and UI responsiveness, it is recommended to use more advanced techniques (ie. moving this into a thread, or
 * using NSURLConnection which runs on its' own thread).
 */
- (void)loadImageOnTimer:(NSTimer *)timer
{
	NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[timer userInfo]]];
	[self setLoadedImage:[UIImage imageWithData:imageData]];
	[_activityView stopAnimating];
}


/**
 * Only use portrait orientation.
 */
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


/**
 * Segmented control value changed.
 */
- (IBAction)colorChanged:(UISegmentedControl *)sender
{
	CGFloat r = 0.0;
	CGFloat g = 0.0;
	CGFloat b = 0.0;
	CGFloat lineWidth = 5.0;
	
	switch (sender.selectedSegmentIndex) {
		case 0:
			r = 1.0; g = 1.0; b = 1.0;
			break;
		case 1:
			r = 0.0; g = 0.0; b = 0.0;
			lineWidth = 20.0;
			break;
		default:
			break;
	}
	
	[_sketch setBrushColorWithRed:r green:g blue:b];
	_sketch.lineWidth = lineWidth;
}


/**
 * Clear button clicked.
 */
- (IBAction)clearButtonClick:(id)sender
{
	[_sketch clear];
}


/**
 * Kik button clicked.
 */
- (IBAction)kikButtonClick:(id)sender
{
	if ( _delegate != nil && [_delegate respondsToSelector:@selector(saveSketchImage:)] ) {
		[_delegate saveSketchImage:_sketch.image];
	}
}


/**
 * Sets the the given image (clears it if it's invalid/nil).
 */
- (void)setLoadedImage:(UIImage *)image
{
	if ( image ) {
		_sketch.image = image;
	}
	else {
		[_sketch clear];
	}
}

@end
